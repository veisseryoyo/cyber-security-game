// כלי מקומי אופציונלי לחישוב התקדמות. המשחק בדפדפן פועל גם בלעדיו.
#include <iostream>
#include <limits>

int main() {
    int completed = 0;
    std::cout << "מספר השערים שהושלמו (0–15): ";
    if (!(std::cin >> completed) || completed < 0 || completed > 15) {
        std::cerr << "מספר השערים אינו תקין.\n";
        return 1;
    }
    std::cout << "גביעים: " << completed << " / 15\n";
    std::cout << "התקדמות: " << completed * 100 / 15 << "%\n";
    return 0;
}
