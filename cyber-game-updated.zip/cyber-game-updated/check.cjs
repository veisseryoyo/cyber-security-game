const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const elements = {};
function element(id) {
  return elements[id] ||= {id, textContent:'', value:'', style:{}, children:Array.from({length:15},()=>({classList:{add(){}}})), classList:{add(){},remove(){},toggle(){}}, addEventListener(event, fn){this[event]=fn;}, setAttribute(){}, set innerHTML(v){this.html=v;}, get innerHTML(){return this.html||'';}};
}
const context = {selected:null,document:{getElementById:element,querySelectorAll:()=>[],querySelector:()=>context.selected,addEventListener(){}},window:{scrollTo(){}},localStorage:{getItem(){return null},setItem(){}},console};
vm.createContext(context);
vm.runInContext(fs.readFileSync('game.js','utf8') + `
  if (gates.length !== 15 || scenarios.length !== 3) throw Error('missing content');
  for (gate=0; gate<15; gate++) {
    renderGate();
    const g=gates[gate];
    if (g.open) document.getElementById('open-answer').value=g.groups.map(x=>x[0]).join(' ');
    else selected={value:String(g.answer)};
    document.getElementById('answer-form').submit({preventDefault(){}});
    if (!answered || completed!==gate+1) throw Error('failed gate '+gate);
  }
`,context);
assert.equal(elements['trophy-count'].textContent,15);
assert.equal(elements['progress-bar'].style.width,'100%');
console.log('All 15 gates accept their expected answers and award trophies.');
